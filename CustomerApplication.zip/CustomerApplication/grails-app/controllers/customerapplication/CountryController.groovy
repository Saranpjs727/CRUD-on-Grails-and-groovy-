package customerapplication
//import java.lang.*;
class CountryController {

    def create() { 
       
    }
    def operation()
    {
    }
    def save()
    {
        def countryInst=new Country(params)
        if(countryInst.validate()){
            countryInst.save(flush:true,failOnError:true)
            render view:"operation"
        }
        else{
            flash.error="Please check all the fields"
            render view:"create"
        }
       
    }
    def display()
    {
        def countryList=Country.list()
        [temp:countryList]
    }
    def delete()
    {
        def countryList=Country.list()
        [countryList:countryList]
    }
    def deleteAction()
    {
        def country=params.country
        def countryInst=Country.get(country)
        countryInst.delete(flush:true)
        render view:"operation"
    }
    def update()
    {
        def countryList=Country.list()
        [countryList:countryList]
    }
    def updateAction()
    {
        def id1=params.oldCountry
        def id=Integer.parseInt(id1)
        // int id= country as Integer
        def countryOld=Country.get(id)
        def countryNew=params.newCountry
         countryOld.country=countryNew
        //Country.executeUpdate("update Country c set c.country='"+countryNew+"' where c.id='"+id+"'")
       // render view:"operation"
        redirect action:"operation"
    }
}

