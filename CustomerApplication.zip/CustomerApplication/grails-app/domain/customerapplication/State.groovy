package customerapplication

class State {

    static constraints = {
        state  nullable: false,blank: false
    }
    static belongsTo=[country:Country]
    static hasMany=[district:District]
    String state;
}
